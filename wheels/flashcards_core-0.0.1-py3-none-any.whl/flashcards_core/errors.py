class ObjectNotFoundException(Exception):
    pass


class NoCardsToStudyException(Exception):
    pass
